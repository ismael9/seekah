function main()
{
  locate();
}
